#ifndef BENCHMARK_INTERNAL_H
#define BENCHMARK_INTERNAL_H

/*
 * benchmark_internal.h（mark3）
 *
 * 角色：
 * - 给 mark3 各 .c 文件提供“内部共享接口”
 * - 汇总 reader/worker/rss/flow 之间的互相依赖声明
 *
 * 你可以把它理解成“实现层 glue header”：
 * - ndpi_benchmark.h 放公共数据结构
 * - benchmark_internal.h 放模块连接点与内部函数原型
 */

#include "ndpi_benchmark.h"

#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#define RSS_TABLE_INIT_CAP (1u << 18)

struct rss_table;
typedef struct rss_table rss_table_t;

typedef struct {
  /* 输入与线程拓扑配置 */
  const char *pcap_file;
  worker_context_t *workers;
  uint32_t num_workers;
  uint32_t num_dispatchers;
  uint32_t *dispatcher_cores;

  /* 运行期 flow->worker 粘性映射 */
  struct rss_table *rss;

  /* 预处理阶段产物（reader 先载入，再由 dispatcher 并发消费） */
  void *packets;
  size_t packet_count;
  size_t *dispatcher_offsets; /* [num_dispatchers + 1] */
  size_t *dispatcher_indices; /* [packet_count], 索引到 packets */

  /* dispatcher 汇总统计时的并发保护 */
  pthread_mutex_t stats_lock;

  /* dispatch 阶段计时（ns） */
  uint64_t read_time_ns;
  uint64_t pcap_read_ns;
  uint64_t normalize_ns;
  uint64_t hash_ns;
  uint64_t rss_lookup_ns;
  uint64_t enqueue_ns;
  uint64_t read_other_ns;

  /* preprocess 阶段计时（ns） */
  uint64_t preprocess_ns;
  uint64_t preprocess_dispatch_rss_ns;
  uint64_t preprocess_store_ns;
  uint64_t preprocess_schedule_ns;
  uint64_t preprocess_other_ns;
} reader_context_t;

extern pthread_mutex_t g_print_mutex;
extern uint64_t g_samples_printed;
extern const uint64_t g_sample_limit;
extern bool g_quiet_mode;

void maybe_print_flow_sample(worker_context_t *w, const bench_flow_t *f);
void set_thread_affinity(uint32_t core);

bool normalize_to_ethernet(int linktype,
                           const uint8_t *data, uint16_t caplen, uint16_t wirelen,
                           const uint8_t **out_data, uint16_t *out_caplen,
                           uint16_t *out_wirelen, uint8_t *scratch,
                           size_t scratch_len);
parse_result_t parse_ethernet_frame(const uint8_t *data, uint16_t caplen, parsed_packet_t *out);
void flow_key_from_packet(const parsed_packet_t *p, flow_key_t *out_key, endpoint_t *out_src, endpoint_t *out_dst);
bool endpoint_equal(const endpoint_t *a, const endpoint_t *b);

uint64_t flow_key_hash(const flow_key_t *k);
struct flow_table *flow_table_create(size_t initial_capacity);
void flow_table_destroy(struct flow_table *ft,
                        void (*on_free)(bench_flow_t *flow, void *user),
                        void *user);
bool flow_table_delete(struct flow_table *ft,
                       const flow_key_t *key,
                       uint64_t key_hash,
                       void (*on_free)(bench_flow_t *flow, void *user),
                       void *user);
bench_flow_t *flow_table_get_or_create(struct flow_table *ft,
                                       const flow_key_t *key,
                                       uint64_t key_hash,
                                       bool *is_new);

#ifdef NDPI_BENCHMARK_CLASSIFIED
struct classified_table *classified_table_create(size_t initial_capacity);
void classified_table_destroy(struct classified_table *ct);
bool classified_table_lookup(const struct classified_table *ct,
                             const flow_key_t *key,
                             uint64_t key_hash,
                             uint16_t *out_app_proto);
void classified_table_insert(struct classified_table *ct,
                             const flow_key_t *key,
                             uint64_t key_hash,
                             uint16_t app_proto);
#endif

rss_table_t *rss_table_create(size_t initial_capacity);
void rss_table_destroy(rss_table_t *rt);
uint32_t rss_mix32(uint32_t x);
uint32_t rss_table_lookup_or_assign(rss_table_t *rt,
                                    const reader_context_t *ctx,
                                    uint64_t key,
                                    uint64_t ts_ms);
uint32_t rss_table_lookup_or_assign_target(rss_table_t *rt,
                                           uint32_t num_targets,
                                           uint64_t key,
                                           uint64_t ts_ms);

void *worker_thread_entry(void *arg);
void *reader_thread_entry(void *arg);

#endif
