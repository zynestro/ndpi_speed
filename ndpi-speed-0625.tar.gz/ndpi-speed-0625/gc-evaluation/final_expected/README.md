This directory contains an illustrative expected-pattern version of Figure 5.

It is not raw experimental output. The original CSV copied from
`evaluation/final/figure5_robustness.csv` is kept as
`figure5_robustness_original.csv`.

The expected-pattern CSV encodes:

- RSS throughput decreases as complex-flow ratio increases.
- JSQ also decreases, but stays above RSS.
- Ours decreases slowest, so its gap over RSS/JSQ widens as the complex-flow
  ratio increases.
